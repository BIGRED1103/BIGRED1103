#要素类Component
class Component:
    def operation(self):
        pass


#非装饰对象，只负责自己的工作，不会调用其他Component的操作
class ConcreteComponent(Component):
    def operation(self):
        print(self, '.operation()')


#装饰器类
class Decorator(Component):
    #初始化，用于准备下级processor对象
    def __init__(self, comp):
        #指定装饰对象
        self.component = comp
    #数据处理方法，调用下级processor方法
    def operation(self):
        self.component.operation()


#装饰器A
class ConcreteDecoratorA(Decorator):
    def operation(self):
        Decorator.operation(self)
        print(self, '.operationA()')


#装饰器B
class ConcreteDecoratorB(Decorator):
    def operation(self):
        Decorator.operation(self)
        print(self, '.operationB()')

#主程序
if __name__ == '__main__':
    print('ConcreteDecoratorB+ConcreteDecoratorA+ConcreteComponent')
    ConcreteDecoratorB(ConcreteDecoratorA(ConcreteComponent())).operation()
    print('ConcreteComponent')
    ConcreteComponent().operation()