import abc

class Mediator(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def notify(self, colleague):
        raise NotImplementedError


class Colleague:
    def __init__(self, mediator):
        self.mediator = mediator


class TextEntry(Colleague):
    def __init__(self, mediator):
        Colleague.__init__(self, mediator)
        self.text = ""

    def set_text(self, text):
        self.text = text
        print('TextEntry:', self.text)


class ListBox(Colleague):
    def __init__(self, mediator):
        Colleague.__init__(self, mediator)
        self.index = 0

    def item_selected(self):
        self.index = self.index + 1
        self.mediator.notify(self)

    def get_selected(self):
        return self.index


class ConcreteMediator(Mediator):
    def __init__(self):
        self.lb = ListBox(self)
        self.te = TextEntry(self)

    def notify(self, colleague):
        if colleague == self.lb:
            self.te.set_text(self.lb.get_selected())

    def test(self):
        self.lb.item_selected()


if __name__ == '__main__':
    mediator = ConcreteMediator()
    mediator.test()
