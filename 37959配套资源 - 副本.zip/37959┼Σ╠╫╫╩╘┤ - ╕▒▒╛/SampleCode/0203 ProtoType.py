import copy

class ConcreteType:
    def __init__(self):
        self.dict = {}

    # clone方法
    def clone(self):
        # 使用deepcopy生成自身的副本
        c = ConcreteType()
        c.dict = copy.copy(self.dict)
        return c

    def set(self, key, value):
        self.dict[key] = value

    def __str__(self):
        return self.dict.__str__()


if __name__ == '__main__':
    print('Test ConcreteType')
    ct = ConcreteType()
    ct.set(5, 'five')
    print('ct:',ct)
    cct = ct.clone()
    print('clone cct')
    print('ct:', ct)
    print('cct:', cct)
    print('change ct')
    ct.set(6, 'six')
    print('ct:', ct)
    print('cct:', cct)