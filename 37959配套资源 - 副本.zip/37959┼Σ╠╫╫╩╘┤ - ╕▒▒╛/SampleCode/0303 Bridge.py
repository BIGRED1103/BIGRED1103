class Vehicle:
    def __init__(self, imp):
        self.imp = imp
    #提供运输服务
    def run(self, distance):
        self.imp.run(distance)

#抽象载具实现类
class VehicleImpl:
    def __init__(self, speed):
        self.speed = speed
    #移动
    def run(self, distance):
       time = round(distance / self.speed, 1)
       return "{}公里，耗时{}小时".format(distance, time)


class PassengerVehicle(Vehicle):
    def __init__(self, imp, passengers):
        Vehicle.__init__(self, imp)
        self.passengers = passengers
    #执行载客任务
    def run(self, distance):
        ret = '载客' + str(self.passengers) + '名'
        ret = ret + ',' + self.imp.run(distance)
        return ret


class CargoVehicle(Vehicle):
    def __init__(self, imp, passengers):
        Vehicle.__init__(self, imp)
        self.passengers = passengers
    #执行运货任务
    def run(self, distance):
        ret = '运货' + str(self.passengers) + '吨'
        ret = ret + ',' + self.imp.run(distance)
        return ret


#飞机
class Plane(VehicleImpl):
    #飞行
    def run(self, distance):
        return '飞行' + VehicleImpl.run(self, distance)
    #汽车


class Automobile(VehicleImpl):
    #运转
    def run(self, distance):
        return '行驶' + VehicleImpl.run(self, distance)


if __name__ == '__main__':
    #时速700公里的飞机，载货200吨，运输距离1000公里
    print(CargoVehicle(Plane(700), 200).run(1000))
    # 时速80公里的汽车，载货20吨，运输距离1000公里
    print(CargoVehicle(Automobile(80), 20).run(1000))
    # 时速800公里的飞机，载客300人，运输距离500公里
    print(PassengerVehicle(Plane(800), 300).run(500))
    # 时速90公里的汽车，载客50人，运输距离500公里
    print(PassengerVehicle(Automobile(90), 50).run(500))