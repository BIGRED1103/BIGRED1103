#小型车体
class MiniBody:
    def __init__(self):
        pass

#小型车轮
class MiniWheel:
    def __init__(self):
        pass

#重型车体
class HeavyBody:
    def __init__(self):
        pass
#大型车轮
class BigWheel:
    def __init__(self):
        pass

#小汽车零件工厂
class CarPartsFactory:
    def create_body(self):
        return MiniBody()
    def create_wheel(self):
        return MiniWheel()

#卡车零件工厂
class TruckPartsFactory:
    def create_body(self):
        return HeavyBody()
    def create_wheel(self):
        return BigWheel()

#车辆类
class Vehicle:
    def __init__(self, t):
        self.type = t
        self.body = None
        self.wheel = []
    #准备车体
    def set_body(self, b):
        self.body = b
        #安装车轮
    def add_wheel(self, w):
        self.wheel.append(w)
    #输出车辆信息
    def print(self):
        print('===', self.type, '===')
        print(type(self.body))
        for w in self.wheel:
            print(type(w))

#组装车辆
def MakeVehicle(type, factory, wheel_count):
    v = Vehicle(type)
    v.set_body(factory.create_body())
    for w in range(0, wheel_count):
        v.add_wheel(factory.create_wheel())
    return v


if __name__ == '__main__':
    #组装小汽车
    MakeVehicle('Car', CarPartsFactory(), 4).print()
    #组装卡车
    MakeVehicle('Truck', TruckPartsFactory(), 6).print()