import sys
import os


class Request1:
    def ouput(self):
        print('Request1!')


class Request2:
    def ouput_msg(self):
        print('Request2!')


class DummyRequest:
    pass


class Handler:
    def __init__(self, successor = None):
        self.successor = successor

    def handle_request(self, request):
        if self.successor:
            self.successor.handle_request(request)
        else:
            print("Tail of the chain reached.")


class ConcreteHandler1(Handler):
    def handle_request(self, request):
        if isinstance(request, Request1):
            request.ouput()
        else:
            print('Request1Handler pass')
            Handler.handle_request(self, request)


class ConcreteHandler2(Handler):
    def handle_request(self, request):
        if isinstance(request, Request2):
            request.ouput_msg()
        else:
            print('Request2Handler pass')
            Handler.handle_request(self, request)


if __name__ == '__main__':
    # 生成由ConcreteHandler1和ConcreteHandler2构成的职责链
    handler = ConcreteHandler1(ConcreteHandler2())
    # 投放DummyRequest
    print("===========DummyRequest==============")
    handler.handle_request(DummyRequest())
    # 投放Request1
    print("===========Request1==================")
    handler.handle_request(Request1())
    # 投放Request2
    print("===========Request2==================")
    handler.handle_request(Request2())




