import copy

class Originator:
    def __init__(self):
        self.a = 0
        self.b = 0
        self.c = 0
    def print(self):
        print('a=', self.a, ',b=', self.b, ',c=', self.c)
    def set_memento(self, m):
        self.__dict__ = m
    def create_memento(self):
        return copy.copy(self.__dict__)


if __name__ == '__main__':
    c = []
    o = Originator()
    o.print()
    c.append(o.create_memento())
    o.a = 1
    o.print()
    c.append(o.create_memento())
    o.b = 2
    o.print()
    c.append(o.create_memento())
    o.c = 3
    o.print()
    print('start undo')
    o.print()
    while len(c):
        o.set_memento(c.pop())
    o.print()