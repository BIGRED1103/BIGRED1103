

class Builder:
    # 铺地面
    # pos：开始位置，length：长度
    def build_floor(self, pos, length):
        pass
    # 砌墙
    #pos：开始位置，length：长度
    def build_wall(self, pos, length):
        pass
    # 安装窗户
    #pos：位置
    def build_window(self, pos):
        pass
    # 安装门
    # pos：位置
    def build_door(self, pos):
        pass


def build_building(builder):
    # 铺一层地面
    builder.build_floor(0, 13)
    # 砌一层墙
    builder.build_wall(1, 11)
    # 安一层窗户
    builder.build_window(3)
    builder.build_window(7)
    builder.build_window(9)
    # 安一层门
    builder.build_door(5)
    # 铺二层地面
    builder.build_floor(1, 11)
    # 砌二层墙
    builder.build_wall(2, 9)
    # 安二层窗户
    builder.build_window(4)
    builder.build_window(6)
    builder.build_window(8)
    # 建屋顶
    builder.build_floor(2, 9)

#'''
#建筑模型
#建筑模型
class ModelBuilder:
    def __init__(self):
        self.current = ''
        self.model = []
    #砌墙
    #pos：开始位置，length：长度
    def build_wall(self, pos, length):
        self.__add_layer()
        self.current = '                                 '
        self.__set_current(pos, '|')
        self.__set_current(pos + length - 1, '|')
    #安装窗户
    #pos：位置
    def build_window(self, pos):
        self.__set_current(pos, 'W')
    #安装门
    #pos：位置
    def build_door(self, pos):
        self.__set_current(pos, 'D')
    #铺地面
    #pos：开始位置，length：长度
    def build_floor(self, pos, length):
        self.__add_layer()
        self.current = ''
        for i in range(pos, pos + length):
            self.__set_current(i, '-')

    def __set_current(self, pos, c):
        while len(self.current) < pos:
            self.current += ' '
        self.current = self.current[:pos] + c + self. current [pos+1:]

    def __add_layer(self):
        if len(self.current):
            self.model.append(self.current)
            self.current = None

    def __str__(self):
        self.__add_layer()
        self.current = ''
        result = ''
        for r in reversed(self.model):
            result = result + r + '\n'
        return result


#物料清单生成器
class BomBuilder:
    def __init__(self):
        self.wall = 0
        self.floor = 0
        self.window = 0
        self.door = 0
    # 铺地面
    # pos：开始位置，length：长度
    def build_floor(self, pos, length):
        self.floor = self.floor + length
    # 砌墙
    # pos：开始位置，length：长度
    def build_wall(self, pos, length):
        self.wall = self.wall + length
    # 安装窗户
    # pos：位置
    def build_window(self, pos):
        self.window = self.window + 1
    # 安装门
    # pos：位置
    def build_door(self, pos):
        self.door = self.door + 1

    def __str__(self):
        bom = 'floor:' + str(self.floor) + 'm\n'
        bom = bom + 'wall:' + str(self.wall) + 'm\n'
        bom = bom + 'window:' + str(self.window) + '\n'
        bom = bom + 'door:' + str(self.door)
        return bom


if __name__ == '__main__':
    print('ModelBuilder demo')
    mb = ModelBuilder()
    build_building(mb)
    print(mb)

    print('BomBuilder demo')
    bb = BomBuilder()
    build_building(bb)
    print(bb)
