class DrawerA:
    def draw_text(self, color, text):
        print(color, text)


class AdapterA:
    def __init__(self):
        self.drawer = DrawerA()
        self.color = None
    def set_color(self, color):
        self.color = color
    def draw_text(self, text):
        self.drawer.draw_text(self.color, text)


class DrawerB:
    def __init__(self):
        self.color = None
    def set_color(self, color):
        self.color = color
    def draw_text(self, text):
        print(self.color, text)


class AdapterB:
    def __init__(self):
        self.drawer = DrawerB()
    def draw_text(self, color, text):
        self.drawer.set_color(color)
        self.drawer.draw_text(text)


if __name__ == '__main__':
    a = AdapterA()
    a.set_color('green')
    a.draw_text('HELLO!')

    b = AdapterB()
    b.draw_text('RED', 'byebye!')
