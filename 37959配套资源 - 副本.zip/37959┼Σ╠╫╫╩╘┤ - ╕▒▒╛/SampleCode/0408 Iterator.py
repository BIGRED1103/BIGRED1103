class Aggregate1:
    #初始化
    def __init__(self):
        self.children = []
    #添加子元素
    def add(self, child):
        self.children.append(child)
    #创建迭代器
    def iter(self):
        return iter(self.children)


class Aggregate2:
    #初始化
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
    #创建迭代器
    def iter(self):
        return iter(self.__dict__.items())


#输出聚合类
def print_aggregate(a, prefix=''):
    #输出聚合类自身
    print(prefix, a)
    try:
        #取得迭代器
        it = a.iter()
    except AttributeError:
        #不支持迭代功能
        pass
    else:
        #支持迭代功能
        for child in it:
            #对子元素递归调用输出方法
            print_aggregate(child, prefix + '')


if __name__ == '__main__':
    a1 = Aggregate1()
    a1.add(Aggregate2(1, 2, 3))
    a1.add(Aggregate2('a1', 'b1', 'c1'))
    print_aggregate(a1)
