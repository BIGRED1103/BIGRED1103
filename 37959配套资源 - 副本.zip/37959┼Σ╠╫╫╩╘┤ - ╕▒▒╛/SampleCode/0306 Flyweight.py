class Component:
    def __init__(self):
        pass

    def operation(self, extrinsicState):
        pass


class FlyweightConcrete(Component):
    def __init__(self, intricsicState):
        Component.__init__(self)
        self.intriscsicState = intricsicState

    def operation(self, extrinsicState):
        print(self, '+', extrinsicState)


class UnsharedConcrete(Component):
    def __init__(self, state):
        Component.__init__(self)
        self.allState = state
    def operation(self, extrinsicState):
        print(self)


class FlyweightFactory:
    def __init__(self):
        self.pool = dict()

    def getFlyweight(self, state):
        flyweight = self.pool.get(state)
        if not flyweight:
            flyweight = FlyweightConcrete(state)
            self.pool[state] = flyweight
        return flyweight

    def getUnshared(self, state):
        return UnsharedConcrete(state)



if __name__=='__main__':
    factory = FlyweightFactory()
    list = []
    list.append(factory.getFlyweight("1"))
    list.append(factory.getFlyweight("1"))
    list.append(factory.getFlyweight("2"))
    list.append(factory.getUnshared('3'))
    list.append(factory.getUnshared('3'))
    ext_info = 0
    for f in list:
        f.operation(ext_info)
        ext_info = ext_info + 1

