class Component:
    def __init__(self):
        pass
    def count_employee(self):
        return 1
    def count_salary(self):
        return 0


class Composite(Component):
    def __init__(self):
        Component.__init__(self)
        self.child = []
    def add(self, child):
        self.child.append(child)
    def count_employee(self):
        count = 0
        for c in self.child:
            count = count + c.count_employee()
        return count
    def count_salary(self):
        sum = 0
        for c in self.child:
            sum = sum + c.count_salary()
        return sum


class Company(Composite):
    def __init__(self, name, type):
        Composite.__init__(self)
        self.name = name
        self.type = type


class Department(Composite):
    def __init__(self, name):
        Composite.__init__(self)
        self.name = name


class Employee(Component):
    def __init__(self, name, salary):
        Component.__init__(self)
        self.name = name
        self.salary = salary

    def count_salary(self):
        return self.salary


#组合模式示例代码
if __name__ == '__main__':
    #构建公司
    c = Company('ABC.co.ltd', 'Software')
    #添加姓赵的员工
    c.add(Employee('Zhao', 20000))
    #构建市场部
    d1 = Department('Markeing')
    #添加姓钱的员工
    d1.add(Employee('Qian', 15000))
    #添加姓孙的员工
    d1.add(Employee('Sun', 12000))
    #将市场部添加到公司组织中
    c.add(d1)
    #构建开发部
    d2 = Department('Development')
    #添加姓李的员工
    d1.add(Employee('Li', 15000))
    #添加姓周的员工
    d1.add(Employee('Zhou', 14000))
    #添加姓吴的员工
    d1.add(Employee('Wu', 12000))
    #添加姓郑的员工
    d1.add(Employee('Zheng', 10000))
    #将开发部添加到公司组织中
    c.add(d2)
    #计算员工人数
    print('Empolyee count:', c.count_employee())
    #计算薪资总额
    print('Total salary:', c.count_salary())