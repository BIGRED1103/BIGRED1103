class Singleton(object):
    __instance = None

    def __new__(cls):
        if not cls.__instance:
            cls.__instance = super(Singleton, cls).__new__(cls)
            cls.__instance.data = 0
        return cls.__instance
    def __init__(self):
        print('Singleton.__init__(),id=', id(self))

    def set_value(self, data):
        print('set data to', data)
        self.data = data

    def get_data(self):
        return self.data

    def __str__(self):
        return 'id={},data={}'.format(id(self), self.data)

if __name__ == '__main__':
    s1 = Singleton()
    print(s1)
    s2 = Singleton()
    print(s2)
    s2.set_value(10)
    print(s1)
    print(s2)