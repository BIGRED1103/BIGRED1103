import random

#电表类
class ElecMeter:
    #抄表
    def read(self):
        return random.randint(100, 300)
    # 检查
    def check(self):
        return random.randint(0, 1)
    # 更换
    def replace(self):
        print('ElecMeter replaced.')

    # 接受访问者
    def accept(self, visitor):
        visitor.visit_e_meter(self)


# 水表类
class WaterMeter:
    # 抄表
    def read(self):
        return random.randint(10, 50)
    # 检查
    def check(self):
        return random.randint(0, 1)
    # 更换
    def replace(self):
        print('WaterMeter replaced.')

    # 接受访问者
    def accept(self, visitor):
        visitor.visit_w_meter(self)


# 煤气表类
class GassMeter:
    # 抄表
    def read(self):
        return random.randint(5, 10)

    # 检查
    def check(self):
        return random.randint(0, 1)

    # 修理
    def repair(self):
        print('GassMeter repaired.')

    # 接受访问者
    def accept(self, visitor):
        visitor.visit_g_meter(self)


class Home:
    def __init__(self, e_meter, w_meter, g_meter):
        self.e_meter = e_meter
        self.w_meter = w_meter
        self.g_meter = g_meter
    def accept(self, visitor):
        if self.e_meter:
            self.e_meter.accept(visitor)
        if self.w_meter:
            self.w_meter.accept(visitor)
        if self.g_meter:
           self.g_meter.accept(visitor)


class MeterReader:
    def __init__(self):
        self.e_value = 0
        self.w_value = 0
        self.g_value = 0
    #抄电表
    def visit_e_meter(self, e_meter):
        self.e_value = self.e_value + e_meter.read()
    #抄水表
    def visit_w_meter(self, w_meter):
        self.w_value = self.w_value + w_meter.read()
    #抄煤气表
    def visit_g_meter(self, g_meter):
        self.g_value = self.g_value + g_meter.read()
    #输出结果
    def __str__(self):
        ret = 'e_value:' + str(self.e_value) + '\n'
        ret = ret + 'w_value:' + str(self.w_value)+ '\n'
        ret = ret + 'g_value:' + str(self.g_value) + '\n'
        return ret


#修理师傅
class MeterRepairMan:
    def __init__(self):
        self.repair_counter = 0
    #检查、更换电表
    def visit_e_meter(self, e_meter):
        if not e_meter.check():
            e_meter.replace()
            self.repair_counter = self.repair_counter + 1
    #检查、更换水表
    def visit_w_meter(self, w_meter):
        if not w_meter.check():
            w_meter.replace()
            self.repair_counter = self.repair_counter + 1
    #检查、修理煤气表
    def visit_g_meter(self, g_meter):
        if not g_meter.check():
            g_meter.repair()
            self.repair_counter = self.repair_counter + 1
    #输出结果
    def __str__(self):
        return 'repair counter:' + str(self.repair_counter)


if __name__ == '__main__':
    # 构建住宅区
    homes = []
    homes.append(Home(ElecMeter(), WaterMeter(), GassMeter()))
    homes.append(Home(ElecMeter(), WaterMeter(), None))
    # 抄表
    mr = MeterReader()
    for h in homes:
        h.accept(mr)
    print(mr)
    # 检修
    mrm = MeterRepairMan()
    for h in homes:
        h.accept(mrm)
    print(mrm)