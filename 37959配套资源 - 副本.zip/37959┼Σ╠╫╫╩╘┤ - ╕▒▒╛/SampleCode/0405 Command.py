import sys
import os


class Receiver:
    def __init__(self):
        self.number = 0
    def action(self, op, prefix):
        self.number = self.number + op
        print(prefix + 'number=', self.number)


class Command:
    def execute(self, prefix):
        pass


class ConcreteCommand(Command):
    def __init__(self, receiver, op):
        self.receiver = receiver
        self.op = op
    def execute(self, prefix):
        print(prefix + 'ConcreteCommand.execute() start')
        self.receiver.action(self.op, prefix + '\t')
        print(prefix + 'ConcreteCommand.execute() end')


class MacroCommand(Command):
    def __init__(self):
        self.cmds = []
    def add(self, cmd):
        self.cmds.append(cmd)
    def execute(self, prefix):
        print(prefix + 'MacroCommand.execute() start')
        for c in self.cmds:
            c.execute(prefix + '\t')
        print(prefix + 'MacroCommand.execute() end')


class Invoker:
    def __init__(self):
        self.cmd = None
    def set_cmd(self, cmd):
        self.cmd = cmd
    def run(self):
        self.cmd.execute('')


if __name__ == '__main__':
    #生成Receiver
    receiver = Receiver()
    #生成简单命令
    cmd = ConcreteCommand(receiver, 10)
    #生成组合命令
    macro_cmd = MacroCommand()
    #添加子命令
    macro_cmd.add(ConcreteCommand(receiver, 1))
    macro_cmd.add(ConcreteCommand(receiver, 2))
    macro_cmd.add(ConcreteCommand(receiver, 3))
    macro_cmd.add(ConcreteCommand(receiver, 4))
    #生成Invoker类
    invoker = Invoker()
    #执行简单命令
    invoker.set_cmd(cmd)
    invoker.run()
    #执行组合命令
    invoker.set_cmd(macro_cmd)
    invoker.run()