import sys
import os
from math import *


class Generator:
    #初始化函数
    #period：周期
    def __init__(self, period):
        self.period = period
    #计算输入值折算到最后一个周期时的占比
    def rate(self, t):
        return (t - int(t / self.period) * self.period) / self.period
    #计算输出
    def output(self, t):
        pass


class SinGenerator(Generator):
    def __init__(self, period):
        Generator.__init__(self, period)
    #计算输出
    def output(self, t):
        return sin(2 * 3.1415926 * self.rate(t))


class SquareGenerator(Generator):
    def __init__(self, period):
        Generator.__init__(self, period)

    #计算输出
    def output(self, t):
        if self.rate(t) < 0.5:
            return -1
        else:
            return 1

def test_strategy(generator):
    result = ''
    #正好输出一个周期
    for t in range(0, 16):
        #调用策略接口
        value = generator.output(t)
        #格式化输出
        result = result + '{:+.2f},'.format(round(value, 2))
    print(result)


if __name__ == '__main__':
    #使用正弦策略，周期20
    test_strategy(SinGenerator(16))
    #使用方波策略，周期20
    test_strategy(SquareGenerator(16))