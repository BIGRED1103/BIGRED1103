class PoliceDrawer:
    def __init__(self, p):
        self.person = p

    #描画方法
    def draw(self):
        print('name:', self.person.name,
              ',age:', self.person.age,
              ',weight', self.person.weight, 'kg')


class Police:
    def __init__(self, a, w, n):
        self.age = a
        self.weight = w
        self.name = n

    # 生成描画对象
    def create_drawer(self):
        return PoliceDrawer(self)

class CarDrawer:
    def __init__(self, c):
        self.car = c
    # 描画方法
    def draw(self):
        print('type:', self.car.type, ',weight', self.car.weight, 'kg')


class Car:
    def __init__(self, t, w):
        self.type = t
        self.weight = w

    # 生成描画对象
    def create_drawer(self):
        return CarDrawer(self)


if __name__ == '__main__':
    # 构建警察对象
    police = Police(30, 70, 'Mr.Green')
    police.create_drawer().draw()
    # 构建汽车
    car = Car('Car', 1200)
    car.create_drawer().draw()