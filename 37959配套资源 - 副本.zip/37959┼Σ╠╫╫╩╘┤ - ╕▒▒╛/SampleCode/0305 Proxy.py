import copy


class Subject:
    def __init__(self, text):
        self.__text = text
    def set_text(self, text):
        self.__text = text
    def text(self):
        return self.__text


class Client:
    def __init__(self, sub):
        self.subject = copy.deepcopy(sub)
    def set_text(self, text):
        self.subject.set_text(text)
    def __str__(self):
        return 'id=' + str(id(self.subject)) + ',text =' + self.subject.text()


if __name__ == '__main__':
    s = Subject('ABCD')
    c1 = Client(s)
    c2 = Client(s)
    print(c1)
    print(c2)
    c1.set_text('EFGH')
    print(c1)
    print(c2)