from Framework.ExecContext import ExecContext


class EcContext(ExecContext):
    pass

