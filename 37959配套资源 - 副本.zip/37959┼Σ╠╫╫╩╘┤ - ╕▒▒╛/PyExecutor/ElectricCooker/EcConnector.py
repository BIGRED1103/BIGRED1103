import sys
sys.path.append('..')

from Framework.Connector import *

class EcConnector(Connector):
    def __init__(self, cd=None):
        Connector.__init__(self, cd, '')





