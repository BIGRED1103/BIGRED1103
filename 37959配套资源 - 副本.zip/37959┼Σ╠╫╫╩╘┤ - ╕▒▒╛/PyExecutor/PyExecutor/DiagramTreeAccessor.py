import sys
import os

from tkinter import PhotoImage
from Foundation.TreeAccessor import TreeAccessor
# from Framework.CustomBlock import CustomBlock


class DiagramTreeAccessor(TreeAccessor):
    def __init__(self, mediator):
        TreeAccessor.__init__(self)
        self.mediator = mediator
        cur_path = os.path.abspath(os.path.dirname(__file__))
        self.__blk_image = PhotoImage(file=cur_path + '\\images\\block.gif')
        self.__diagram_image = PhotoImage(file=cur_path + '\\images\\diagram.gif')

    def get_parent(self, node):
        return node.parent

    # 取得节点名称
    def get_name(self, node):
        return node.name

    # 取得节点图标
    def get_image(self, node):
        from Framework.Diagram import Diagram
        # 根据节点类型返回图标
        if isinstance(node, Diagram):
            return self.__diagram_image
        else:
            return self.__blk_image

    # 取得节点iid
    def get_iid(self, node):
        # 返回Component的tag
        return node.tag

    # 取得下级节点
    def get_children(self, node):
        return node.iter('tree_node')

    def focus(self, iid):
        self.mediator.focus(iid)








