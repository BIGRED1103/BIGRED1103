class BuilderFactory:
    def builder_types(self):
        pass

    def make_builder(self, type):
        pass