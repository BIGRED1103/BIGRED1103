class EditCommand:
    def __init__(self, cmd, target=None, x=0, y=0):
        self.cmd = cmd
        self.target = cmd
        self.x = x
        self.y = y
