class SourceBuilder:
    def start(self):
        pass

    def stop(self):
        pass

    def build_fun(self):
        pass

    def set_input(self):
        pass

    def set_input_value(self):
        pass

    def set_output(self):
        pass

