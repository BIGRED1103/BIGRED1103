class ExecContext:
    def __init__(self):
        pass
