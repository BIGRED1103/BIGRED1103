class PortVisitor:
    def visitInputPort(self, port):
        pass
    def visitOutputPort(self, port):
        pass