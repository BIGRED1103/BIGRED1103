class Trigger:
    def __init__(self, context):
        self.context = context

    def entry(self):
        pass

    def check(self):
        pass