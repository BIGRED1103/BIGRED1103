# 数据封装器
class DataPacker:
    # 数据打包处理
    def pack(self, data):
        # 缺省情况下什么也不做
        return data
    # 数据解包处理
    def un_pack(self, data):
        # 缺省情况下成么也不做
        return data
