from FunctionBlock.DisplayData import *


class ValueData(DisplayData):
    def __init__(self):
        DisplayData.__init__(self)
        self.data = 0

    def draw(self):
        pass
