import json

class FbdEncoder(json.JSONEncoder):
    def default(self, obj):
        pass
