from FunctionBlock.DisplayData import *


class BufferData(DisplayData):
    def __init__(self):
        DisplayData.__init__(self)
        self.data = []

    def draw(self):
        pass
