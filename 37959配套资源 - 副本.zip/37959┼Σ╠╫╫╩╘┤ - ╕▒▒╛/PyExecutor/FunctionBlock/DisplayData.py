
class DisplayData:
    def __init__(self):
        pass
