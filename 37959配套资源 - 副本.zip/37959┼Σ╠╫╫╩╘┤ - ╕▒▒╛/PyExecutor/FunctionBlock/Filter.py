class Filter:
    def __init__(self):
        self.t = 0

    def start(self):
        self.t = 0

    def run(self, value, p1, p2, p3):
        pass

    def stop(self):
        self.t = 0

