class Security:
    def __init__(self):
        pass

    def encode(self, data):
        return None

    def decode(self, data):
        return None