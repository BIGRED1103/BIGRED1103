#


class Expr:
    def evaluate(self, context):
        return False


