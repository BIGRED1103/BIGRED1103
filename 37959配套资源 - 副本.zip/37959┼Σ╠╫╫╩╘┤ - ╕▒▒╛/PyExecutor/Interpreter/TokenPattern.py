from Interpreter.Token import *


class TokenPattern:
    def __init__(self, _type, _pattern):
        self.pattern = _pattern
        self.type = _type
