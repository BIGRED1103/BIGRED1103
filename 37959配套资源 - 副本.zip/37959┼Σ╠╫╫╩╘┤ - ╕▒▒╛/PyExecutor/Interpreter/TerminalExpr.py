from Interpreter.Expr import *

class TerminalExpr(Expr):
    pass
